fun main(args: Array<String>) {

  val intArray2 = Array  (4, { i -> i * i })


  for(i in intArray2 )
  println(i)

}